import fs from "fs"
import path from "path"
import youtubedl from "youtube-dl-exec"
import sanitize from "sanitize-filename"
import fetch from "node-fetch"
import { spawn } from "child_process"
import { BASE_DIR, FILES_DIR, TMP_DIR, VIDEO_QUALITIES, YOUTUBE_API_KEY } from "./constants.js"
import { downloadImage, formatDuration, formatNumber, getMimetype, getFileSize } from "./utils.js"
import { ProgressTracker, parseYouTubeProgress } from "./progress.js"

// Parse YouTube search command
export function parseYouTubeCommand(commandParts) {
  const fullCommand = commandParts.slice(1).join(" ")

  const dashMatch = fullCommand.match(/^(.+?)\s+-(\d+)$/)
  if (dashMatch) {
    return {
      query: dashMatch[1].replace(/^["']|["']$/g, "").trim(),
      maxResults: Number.parseInt(dashMatch[2]),
    }
  }

  const quotedMatch = fullCommand.match(/^["'](.+?)["']\s+(\d+)$/)
  if (quotedMatch) {
    return {
      query: quotedMatch[1].trim(),
      maxResults: Number.parseInt(quotedMatch[2]),
    }
  }

  const parts = fullCommand.split(/\s+/)
  const lastPart = parts[parts.length - 1]
  if (/^\d+$/.test(lastPart) && parts.length > 1) {
    return {
      query: parts
        .slice(0, -1)
        .join(" ")
        .replace(/^["']|["']$/g, "")
        .trim(),
      maxResults: Number.parseInt(lastPart),
    }
  }

  return {
    query: fullCommand.replace(/^["']|["']$/g, "").trim(),
    maxResults: 5,
  }
}

// YouTube API functions
export async function searchYouTubeVideos(query, maxResults = 5) {
  try {
    const searchUrl = `https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&q=${encodeURIComponent(query)}&maxResults=${maxResults}&order=relevance&key=${YOUTUBE_API_KEY}`
    const response = await fetch(searchUrl)
    const data = await response.json()

    if (!response.ok) {
      throw new Error(data.error?.message || "YouTube API request failed")
    }
    if (!data.items || data.items.length === 0) {
      return { success: false, error: "No videos found for this search query" }
    }

    const videoIds = data.items.map((item) => item.id.videoId).join(",")
    const statsUrl = `https://www.googleapis.com/youtube/v3/videos?part=statistics,contentDetails&id=${videoIds}&key=${YOUTUBE_API_KEY}`
    const statsResponse = await fetch(statsUrl)
    const statsData = await statsResponse.json()

    if (!statsResponse.ok) {
      throw new Error(statsData.error?.message || "Failed to get video statistics")
    }

    const videos = data.items.map((item) => {
      const stats = statsData.items.find((stat) => stat.id === item.id.videoId)
      return {
        id: item.id.videoId,
        title: item.snippet.title,
        description: item.snippet.description,
        thumbnail:
          item.snippet.thumbnails.high?.url ||
          item.snippet.thumbnails.medium?.url ||
          item.snippet.thumbnails.default?.url,
        channelTitle: item.snippet.channelTitle,
        publishedAt: item.snippet.publishedAt,
        url: `https://www.youtube.com/watch?v=${item.id.videoId}`,
        views: stats?.statistics?.viewCount || "N/A",
        likes: stats?.statistics?.likeCount || "N/A",
        duration: stats?.contentDetails?.duration || "N/A",
      }
    })
    return { success: true, videos }
  } catch (error) {
    console.error("Youtube search failed:", error.message)
    return { success: false, error: error.message }
  }
}

// Send compact video search results
export async function sendVideoSearchResults(sock, remoteJid, videos) {
  try {
    await sock.sendMessage(remoteJid, {
      text: `🔍 Found ${videos.length} videos:\n\n📝 Reply: <number> <quality>\nExample: 2 1080 or 1 480`,
    })

    for (let i = 0; i < videos.length; i++) {
      const video = videos[i]
      const publishDate = new Date(video.publishedAt).toLocaleDateString()
      const duration = formatDuration(video.duration)
      const views = formatNumber(video.views)
      const likes = formatNumber(video.likes)

      const videoText = `*${i + 1}. ${video.title}*\n\n📺 ${video.channelTitle}\n👀 ${views} | 👍 ${likes}\n⏱️ ${duration} | 📅 ${publishDate}`

      try {
        const thumbnailBuffer = await downloadImage(video.thumbnail)
        if (thumbnailBuffer) {
          await sock.sendMessage(remoteJid, {
            image: thumbnailBuffer,
            caption: videoText,
            mimetype: "image/jpeg",
          })
        } else {
          await sock.sendMessage(remoteJid, { text: videoText })
        }
      } catch (error) {
        await sock.sendMessage(remoteJid, { text: videoText })
      }

      await new Promise((resolve) => setTimeout(resolve, 800))
    }

    const qualityInstructions = `✅ All ${videos.length} videos loaded!\n\n🎬 Quality Options:\n🔹 480 - 480p SD\n🔹 720 - 720p HD\n🔹 1080 - 1080p FHD\n\n📝 Format: <video_number> <quality>\nExamples: 1 1080, 3 720, 5 480`

    await sock.sendMessage(remoteJid, { text: qualityInstructions })
  } catch (error) {
    console.error("Error sending video search results:", error)
    await sock.sendMessage(remoteJid, { text: "❌ Error displaying video results." })
  }
}

// Enhanced YouTube video download with improved progress tracking
export async function downloadYouTubeVideo(videoUrl, quality = "1080", progressTracker = null) {
  let videoInfo = null
  const cookiePath = path.join(BASE_DIR, "youtube_cookies.txt")
  const hasCookies = fs.existsSync(cookiePath)

  const baseOptions = {
    noWarnings: true,
    noCheckCertificate: true,
    preferFreeFormats: true,
    youtubeSkipDashManifest: false,
    userAgent:
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    retries: 3,
    fragmentRetries: 3,
    sleepInterval: 2,
    maxSleepInterval: 10,
  }

  if (hasCookies) {
    baseOptions.cookies = cookiePath
  }

  try {
    videoInfo = await youtubedl(videoUrl, {
      ...baseOptions,
      dumpSingleJson: true,
    })

    const title = sanitize(videoInfo.title || `youtube_video_${Date.now()}`)
    const format = VIDEO_QUALITIES[quality]?.format || VIDEO_QUALITIES["720"].format
    const outputPathTemplate = path.join(TMP_DIR, `${title}_${quality}p.%(ext)s`)
    const expectedPath = path.join(TMP_DIR, `${title}_${quality}p.mp4`)

    const ytdlpArgs = [
      videoUrl,
      "--no-warnings",
      "--no-check-certificate",
      "--prefer-free-formats",
      "--youtube-skip-dash-manifest",
      "--user-agent",
      baseOptions.userAgent,
      "--retries",
      "3",
      "--fragment-retries",
      "3",
      "--sleep-interval",
      "2",
      "--max-sleep-interval",
      "10",
      "--output",
      outputPathTemplate,
      "--format",
      format,
      "--merge-output-format",
      "mp4",
      "--add-metadata",
      "--newline", // Force newline after each progress update
    ]

    if (hasCookies) {
      ytdlpArgs.push("--cookies", cookiePath)
    }

    const ytdlpProcess = spawn("yt-dlp", ytdlpArgs, {
      stdio: ["pipe", "pipe", "pipe"],
    })

    let lastProgressUpdate = 0
    let downloadCompleted = false

    return new Promise((resolve, reject) => {
      ytdlpProcess.stdout.on("data", (data) => {
        const output = data.toString()
        const lines = output.split("\n")

        for (const line of lines) {
          if (line.trim() && progressTracker && !downloadCompleted) {
            const now = Date.now()
            if (now - lastProgressUpdate >= 3000 || line.includes("[download] 100%")) {
              parseYouTubeProgress(line, progressTracker)
              lastProgressUpdate = now

              // Mark as completed when we see 100%
              if (line.includes("[download] 100%") && !line.includes("fragment")) {
                downloadCompleted = true
              }
            }
          }
        }
      })

      ytdlpProcess.stderr.on("data", (data) => {
        const output = data.toString()
        const lines = output.split("\n")

        for (const line of lines) {
          if (line.trim() && progressTracker && !downloadCompleted) {
            const now = Date.now()
            if (now - lastProgressUpdate >= 3000 || line.includes("[download] 100%")) {
              parseYouTubeProgress(line, progressTracker)
              lastProgressUpdate = now

              // Mark as completed when we see 100%
              if (line.includes("[download] 100%") && !line.includes("fragment")) {
                downloadCompleted = true
              }
            }
          }
        }
      })

      ytdlpProcess.on("close", (code) => {
        if (code === 0) {
          let downloadedPath = expectedPath
          if (!fs.existsSync(downloadedPath)) {
            const possibleExtensions = [".mkv", ".webm", ".mp4"]
            for (const ext of possibleExtensions) {
              const altPath = path.join(TMP_DIR, `${title}_${quality}p${ext}`)
              if (fs.existsSync(altPath)) {
                downloadedPath = altPath
                break
              }
            }
          }

          if (!fs.existsSync(downloadedPath)) {
            reject(new Error(`Output file not found after download`))
            return
          }

          const finalFilename = `${title}_${quality}p.${path.extname(downloadedPath).slice(1)}`
          const finalPath = path.join(FILES_DIR, finalFilename)

          fs.copyFileSync(downloadedPath, finalPath)

          resolve({
            success: true,
            filename: finalFilename,
            tempPath: downloadedPath,
            finalPath: finalPath,
            title: title,
            quality: VIDEO_QUALITIES[quality]?.label || `${quality}p`,
          })
        } else {
          reject(new Error(`yt-dlp process exited with code ${code}`))
        }
      })

      ytdlpProcess.on("error", (error) => {
        reject(error)
      })
    })
  } catch (err) {
    console.error("YouTube download failed:", err.stderr || err.message || err)
    return { success: false, error: err.message || "Download failed", title: videoInfo?.title || "Unknown Video" }
  }
}

// Enhanced download and send video with progress tracking
export async function downloadAndSendVideo(sock, remoteJid, video, quality) {
  try {
    await sock.sendPresenceUpdate("composing", remoteJid)

    const progressTracker = new ProgressTracker(sock, remoteJid, 1, "video")
    await progressTracker.start()

    await progressTracker.updateCurrentItem(`${video.title}`, "downloading")

    const result = await downloadYouTubeVideo(video.url, quality, progressTracker)

    await progressTracker.itemCompleted(`${video.title}`, result.success)
    await progressTracker.finish()

    if (result.success) {
      const fileSize = getFileSize(result.finalPath)

      await sock.sendMessage(remoteJid, {
        text: `✅ Download completed!\n📁 ${result.filename}\n📊 Size: ${fileSize}\n🎬 Quality: ${result.quality}\n\n📤 Sending...`,
      })

      await sock.sendMessage(remoteJid, {
        document: { url: result.finalPath },
        fileName: result.filename,
        mimetype: getMimetype(result.filename),
        caption: `🎥 ${video.title}\n\n📺 ${video.channelTitle}\n📊 Size: ${fileSize}\n🎬 Quality: ${result.quality}`,
      })

      if (result.tempPath && fs.existsSync(result.tempPath)) {
        fs.unlinkSync(result.tempPath)
      }

      await sock.sendMessage(remoteJid, { text: `✅ Video sent successfully!\n💾 File saved permanently` })
    } else {
      await sock.sendMessage(remoteJid, { text: `❌ Download failed\n🔴 Error: ${result.error}` })
    }
    await sock.sendPresenceUpdate("available", remoteJid)
  } catch (error) {
    console.error("Error in downloadAndSendVideo:", error)
    await sock.sendMessage(remoteJid, { text: `❌ Download error: ${error.message}` })
    await sock.sendPresenceUpdate("available", remoteJid)
  }
}

// Handle video selection with quality
export async function handleVideoSelection(sock, messageInfo, selection, userStates) {
  const { remoteJid } = messageInfo
  const userState = userStates.get(remoteJid)

  if (!userState || !userState.searchResults) {
    await sock.sendMessage(remoteJid, { text: "❌ No search results found. Use /ys command first." })
    return
  }

  const parts = selection.trim().split(/\s+/)
  if (parts.length !== 2) {
    await sock.sendMessage(remoteJid, {
      text: "❌ Invalid format. Use: <video_number> <quality>\nExample: 2 1080 or 1 480",
    })
    return
  }

  const videoIndex = Number.parseInt(parts[0]) - 1
  const quality = parts[1]

  if (isNaN(videoIndex) || videoIndex < 0 || videoIndex >= userState.searchResults.length) {
    await sock.sendMessage(remoteJid, { text: `❌ Invalid video number. Choose 1-${userState.searchResults.length}` })
    return
  }

  if (!["480", "720", "1080"].includes(quality)) {
    await sock.sendMessage(remoteJid, { text: "❌ Invalid quality. Choose: 480, 720, or 1080" })
    return
  }

  const video = userState.searchResults[videoIndex]
  await downloadAndSendVideo(sock, remoteJid, video, quality)
}
