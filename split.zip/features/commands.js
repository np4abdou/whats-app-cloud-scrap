import fs from "fs"
import { PROGRESS_FILE, ANIME_DOWNLOAD_DIR } from "./constants.js"
import { getWorkspaceFiles } from "./utils.js"
import { getStorageInfo, cleanupTempFiles, savedChats } from "./storage.js"
import { sendFileList, handleFileUpload, handleFileDelete } from "./files.js"
import { parseYouTubeCommand, searchYouTubeVideos, sendVideoSearchResults } from "./youtube.js"
import { handleAnimeCommand } from "./anime.js"
import { activeDownloads } from "./progress.js"

// Safety functions for bot management
export async function restartBot() {
  console.log("🔄 Bot restart requested...")

  // Clear all active downloads
  activeDownloads.clear()

  // Clear progress file
  try {
    if (fs.existsSync(PROGRESS_FILE)) {
      fs.unlinkSync(PROGRESS_FILE)
    }
  } catch (error) {
    console.log("Could not clean progress file:", error.message)
  }

  console.log("🔄 Terminating current process...")

  // Simply exit with code 0 - bot manager will restart us
  process.exit(0)
}

export async function stopBot() {
  console.log("🛑 Bot stop requested...")

  // Clear all active downloads
  activeDownloads.clear()

  // Clear progress file
  try {
    if (fs.existsSync(PROGRESS_FILE)) {
      fs.unlinkSync(PROGRESS_FILE)
    }
  } catch (error) {
    console.log("Could not clean progress file:", error.message)
  }

  console.log("🛑 Stopping bot...")
  process.exit(1)
}

// Send welcome message for new users
export async function sendWelcomeMessage(sock, remoteJid) {
  const welcomeText = `🤖 *Welcome to Enhanced WhatsApp Bot!*

✨ *I can help you with:*
• 📁 File sharing and management
• 🎥 YouTube video downloads  
• 🎌 Enhanced anime downloads with automation

*🚀 Enhanced Features:*
• Real-time progress tracking
• Automatic file sending
• Episode range support
• File size display

*Quick Commands:*
• */help* - Show all commands
• */files* - Browse files
• */ys <query>* - Search YouTube
• */anime <query>* - Search anime
• */anime <name> <episode> <quality>* - Auto download

*🎌 Enhanced Anime Examples:*
• */anime naruto* - Interactive search
• */anime "one piece" 124 1080* - Auto download episode 124
• */anime "death note" 1-6 720* - Download episodes 1-6

📝 *Type /help for detailed instructions!*`

  try {
    await sock.sendMessage(remoteJid, { text: welcomeText })
  } catch (error) {
    console.error("Error sending welcome message:", error)
  }
}

// Send welcome message to all saved chats (optional)
export async function broadcastWelcomeMessage(sock, force = false) {
  if (!force && savedChats.size === 0) {
    console.log("📢 No saved chats to broadcast to")
    return
  }

  const welcomeText = `🤖 *Enhanced WhatsApp Bot Online!*

✨ *Available Commands:*
• */help* - Show all commands
• */files* - Browse files
• */upload <number>* - Send file
• */delete <number>* - Delete file
• */ys <query> -<number>* - Search YouTube
• */anime <query>* - Interactive anime downloads
• */anime <name> <episode> <quality>* - Automated download
• */anime <name> <start-end> <quality>* - Range download
• */storage* - Check storage
• */cleanup* - Clean temp files
• */restart* - Restart bot
• */stop* - Stop bot

*🚀 New Features:*
• Real-time progress tracking
• Automatic file sending
• Episode range support (1-25)
• Conflict awareness with confirmation
• File size display
• Minimal logging

*Examples:*
• */anime "one piece" 124 1080* - Download episode 124
• */anime "naruto" 1-25 720* - Download episodes 1-25`

  console.log(`📢 Broadcasting to ${savedChats.size} chats...`)
  let successCount = 0
  let failCount = 0

  for (const jid of savedChats) {
    try {
      await sock.sendMessage(jid, { text: welcomeText })
      successCount++
      await new Promise((resolve) => setTimeout(resolve, 1000)) // Longer delay between messages
    } catch (error) {
      console.error(`Failed to send welcome to ${jid}: ${error.message}`)
      failCount++
    }
  }

  console.log(`📢 Broadcast complete: ${successCount} sent, ${failCount} failed`)
}

// Handle commands
export async function handleCommand(sock, messageInfo, command, userStates) {
  const { remoteJid } = messageInfo
  const commandParts = command.split(" ")
  const mainCommand = commandParts[0].toLowerCase()

  switch (mainCommand) {
    case "/anime":
      if (commandParts.length < 2) {
        await sock.sendMessage(remoteJid, {
          text: `❌ Please provide an anime name.

*Usage:*
• */anime <name>* - Interactive search
• */anime <name> <episode> <quality>* - Auto download
• */anime <name> <start-end> <quality>* - Range download

*Examples:*
• */anime naruto* - Search Naruto
• */anime "one piece" 124 1080* - Download episode 124
• */anime "death note" 1-6 720* - Download episodes 1-6

*Quality options:* 480, 720, 1080`,
        })
        break
      }

      await handleAnimeCommand(sock, remoteJid, commandParts, userStates)
      break

    case "/files":
      const files = getWorkspaceFiles()
      if (files.length === 0) {
        await sock.sendMessage(remoteJid, { text: "📁 No files found in the files directory." })
        return
      }

      userStates.set(remoteJid, { state: "selecting_file", files: files })
      await sendFileList(sock, remoteJid, files)
      break

    case "/upload":
      if (commandParts.length < 2) {
        await sock.sendMessage(remoteJid, {
          text: "❌ Please specify file number.\n\n*Usage:* /upload <number>\n*Example:* /upload 1\n\n💡 Use /files first to see available files",
        })
        break
      }

      const uploadFileNumber = commandParts[1]
      await handleFileUpload(sock, messageInfo, uploadFileNumber, userStates)
      break

    case "/delete":
      if (commandParts.length < 2) {
        await sock.sendMessage(remoteJid, {
          text: `❌ Please specify file number(s).

*Usage:* 
• /delete <number> - Delete single file
• /delete <number>,<number> - Delete multiple files

*Examples:* 
• /delete 3 - Delete third file
• /delete 1,3,5 - Delete files 1, 3, and 5

💡 Use /files first to see available files`,
        })
        break
      }

      const deleteFileNumbers = commandParts[1]
      await handleFileDelete(sock, messageInfo, deleteFileNumbers, userStates)
      break

    case "/ys":
      if (commandParts.length < 2) {
        await sock.sendMessage(remoteJid, {
          text: `❌ Please provide a search query.

*Usage Examples:*
• /ys "dream manhunt" 5 - Search with quotes
• /ys minecraft -10 - Search with dash format
• /ys speedrun 3 - Simple search

📝 Format: /ys <query> -<number>
📝 Or: /ys "<query>" <number>`,
        })
        break
      }

      try {
        const { query, maxResults } = parseYouTubeCommand(commandParts)

        if (!query) {
          await sock.sendMessage(remoteJid, { text: "❌ Please provide a valid search query." })
          break
        }

        await sock.sendPresenceUpdate("composing", remoteJid)
        await sock.sendMessage(remoteJid, { text: `🔍 Searching: "${query}" (${maxResults} results)...` })

        const searchResult = await searchYouTubeVideos(query, maxResults)

        if (searchResult.success && searchResult.videos.length > 0) {
          userStates.set(remoteJid, {
            state: "video_search_results",
            searchResults: searchResult.videos,
          })
          await sendVideoSearchResults(sock, remoteJid, searchResult.videos)
        } else {
          await sock.sendMessage(remoteJid, {
            text: `❌ YouTube Search Failed: ${searchResult.error || "No videos found."}`,
          })
        }
        await sock.sendPresenceUpdate("available", remoteJid)
      } catch (error) {
        console.error("YouTube search error:", error)
        await sock.sendMessage(remoteJid, { text: `❌ Search failed: ${error.message}` })
        await sock.sendPresenceUpdate("available", remoteJid)
      }
      break

    case "/restart":
      await sock.sendMessage(remoteJid, { text: "🔄 Restarting bot... All processes will be stopped and restarted." })
      await restartBot()
      break

    case "/stop":
      await sock.sendMessage(remoteJid, { text: "🛑 Stopping bot... Core bash terminal will be stopped." })
      await stopBot()
      break

    case "/help":
      const helpText = `🤖 *Enhanced WhatsApp Bot Help*

*📋 Available Commands:*
• */files* - Browse files
• */upload <number>* - Send file by number
• */delete <number>* - Delete file by number
• */delete <number>,<number>* - Delete multiple files
• */ys <query> -<number>* - Search YouTube videos
• */anime <query>* - Interactive anime downloads
• */anime <name> <episode> <quality>* - Automated download
• */anime <name> <start-end> <quality>* - Range download
• */storage* - Check storage usage
• */cleanup* - Clean temporary files
• */restart* - Restart bot (stops all processes)
• */stop* - Stop bot core
• */help* - Show this help

*🚀 Enhanced Features:*
• Real-time progress tracking
• Automatic file sending after download
• Episode range support (1-25, 15-30, etc.)
• Conflict awareness with anime confirmation
• File size display for all operations
• Clean progress messages (old ones deleted automatically)
📤 Auto-send - Files sent immediately after download
📊 File sizes - Shows "X% of Y MB" format
📈 Real-time progress - Live updates every 5 seconds for both anime and YouTube
🗑️ Smart cleanup - Only temp files removed
📱 Minimal logging - Reduced spam, better performance`

      await sock.sendMessage(remoteJid, { text: helpText })
      break

    case "/storage":
      try {
        const storageInfo = getStorageInfo()
        const storageMessage =
          `📊 *Storage Information:*\n\n` +
          `📁 *Files Directory:* ${storageInfo.workspaceSize}\n` +
          `🗂️ *Files Count:* ${storageInfo.filesCount} files\n` +
          `🗑️ *Temp Directory:* ${storageInfo.tempSize}\n` +
          `🎌 *Anime Downloads:* ${storageInfo.animeSize}\n` +
          `📍 *Anime Path:* ${ANIME_DOWNLOAD_DIR}\n\n` +
          `🍪 *YouTube Cookies:* ${storageInfo.hasCookies ? "✅ Found" : "❌ Not found"}\n` +
          `💾 *Saved Chats:* ${storageInfo.savedChatsCount} chats\n` +
          `📊 *Active Downloads:* ${activeDownloads.size} sessions\n\n` +
          `💡 Use /cleanup to free up temporary files\n` +
          `🔧 Use /restart if bot is stuck or lagging\n` +
          `🛑 Use /stop to stop core bash terminal`
        await sock.sendMessage(remoteJid, { text: storageMessage })
      } catch (error) {
        await sock.sendMessage(remoteJid, { text: `❌ Storage check failed: ${error.message}` })
      }
      break

    case "/cleanup":
      try {
        await sock.sendMessage(remoteJid, { text: "🧹 Starting cleanup..." })
        const tempFilesDeleted = await cleanupTempFiles()

        try {
          if (fs.existsSync(PROGRESS_FILE)) {
            fs.unlinkSync(PROGRESS_FILE)
          }
        } catch (error) {
          console.log("Could not clean progress file:", error.message)
        }

        await sock.sendMessage(remoteJid, {
          text: `✅ Cleanup completed!\n\n🗑️ Removed ${tempFilesDeleted} temporary files\n💾 Files directory preserved\n🎌 Anime downloads preserved\n📊 Progress tracking reset`,
        })
      } catch (error) {
        await sock.sendMessage(remoteJid, { text: `❌ Cleanup error: ${error.message}` })
      }
      break

    case "/broadcast":
      if (savedChats.size === 0) {
        await sock.sendMessage(remoteJid, { text: "📢 No saved chats to broadcast to." })
        break
      }

      await sock.sendMessage(remoteJid, {
        text: `📢 Starting broadcast to ${savedChats.size} chats...`,
      })

      await broadcastWelcomeMessage(sock, true)

      await sock.sendMessage(remoteJid, {
        text: `✅ Broadcast completed!`,
      })
      break

    default:
      await sock.sendMessage(remoteJid, { text: "❓ Unknown command. Type /help for available commands." })
  }
}
